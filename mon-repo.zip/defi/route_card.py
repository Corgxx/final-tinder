import streamlit as st
import html
import pydeck as pdk
from defi.ui_components import inject_custom_css
from defi.swisstopo_hiking import get_swisstopo_hiking_routes
from defi.cycling import get_cycling_route

def render_route_card(activity, distance_km=None, on_skip=None, on_match=None):
    inject_custom_css()

    # --- Infos de base ---
    name = html.escape(activity.get("name", "Unknown"))
    category = html.escape(activity.get("category", "Activity"))
    address = html.escape(activity.get("address", "No address"))
    price = activity.get("price", "")
    lat = activity.get("lat")
    lon = activity.get("lon")

    # --- Debug base ---
    st.write("🔍 Activity category:", category)
    st.write("📍 Coordinates:", lat, lon)

    st.markdown(f"<h2 style='text-align:center'>{name}</h2>", unsafe_allow_html=True)
    st.markdown(f"<p style='text-align:center; color:gray'>{address}</p>", unsafe_allow_html=True)

    # --- Route ORS ---
    if category.lower() == "hiking":
        st.write("🟢 Calling hiking route...")
        route = get_hiking_route(lat, lon)
    elif category.lower() == "cycling":
        st.write("🔵 Calling cycling route...")
        route = get_cycling_route(lat, lon)
    else:
        route = None

    # --- Affichage de la carte ---
    if route:
        st.write("✅ Route loaded:", route)
        st.pydeck_chart(pdk.Deck(
            map_style='mapbox://styles/mapbox/light-v9',
            initial_view_state=route["view"],
            layers=[route["layer"]]
        ))

        # Infos complémentaires
        st.markdown(f"**Duration**: {route.get('duration')}")
        st.markdown(f"**Elevation gain**: {route.get('elevation_gain')}")
        st.markdown(f"**Difficulty**: {route.get('difficulty')}")

    else:
        st.warning("⚠️ No route data available.")

    # --- Boutons swipe ---
    col1, col2 = st.columns(2)
    with col1:
        if on_skip and st.button("❌ Pass"):
            on_skip()
    with col2:
        if on_match and st.button("✅ Match"):
            on_match()
