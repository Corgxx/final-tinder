import requests
import pydeck as pdk
import streamlit as st  # nécessaire pour debug visuel

def get_cycling_route(lat, lon):
    st.write("🚴 Function called: get_cycling_route")
    st.write("📍 Coordinates received:", lat, lon)

    api_key = "5b3ce3597851110001cf6248ee3c2977b26a41be8e066e26be3f95bf"
    url = "https://api.openrouteservice.org/v2/directions/cycling-regular"
    headers = {"Authorization": api_key}

    # Destination ~2km plus loin
    dest_lat = lat + 0.02
    dest_lon = lon + 0.02

    body = {
        "coordinates": [[lon, lat], [dest_lon, dest_lat]],
        "elevation": True
    }

    response = requests.post(url, json=body, headers=headers)

    # DEBUG API CALL
    st.write("🔁 ORS status:", response.status_code)
    st.write("🧾 ORS raw response:", response.text[:300])

    if response.status_code != 200:
        st.error(f"❌ ORS ERROR {response.status_code}: {response.text}")
        return None

    data = response.json()

    coords = data["features"][0]["geometry"]["coordinates"]
    summary = data["features"][0]["properties"]["summary"]
    ascent = data["features"][0]["properties"].get("ascent", "N/A")

    # Convert [lon, lat] → [lat, lon] for pydeck
    path_coords = [[lat, lon] for lon, lat in coords]
    route_data = [{"path": path_coords}]

    # PathLayer for PyDeck
    layer = pdk.Layer(
        "PathLayer",
        data=route_data,
        get_path="path",
        get_color=[0, 120, 255],
        width_scale=10,
        width_min_pixels=2,
        pickable=False
    )

    midpoint = path_coords[len(path_coords) // 2]
    view = pdk.ViewState(
        latitude=midpoint[0],
        longitude=midpoint[1],
        zoom=13,
        pitch=0
    )

    st.write("✅ Route successfully built.")

    return {
        "view": view,
        "layer": layer,
        "duration": f"{round(summary['duration'] / 60)} min",
        "elevation_gain": f"{ascent} m",
        "difficulty": "Estimated"
    }
