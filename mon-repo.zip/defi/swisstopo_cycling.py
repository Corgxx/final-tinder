import requests
import pydeck as pdk
import streamlit as st

def get_swisstopo_cycling_routes(lat, lon, delta=0.05):
    """
    Récupère les itinéraires cyclables autour du point via GeoAdmin.
    """
    bbox = f"{lon-delta},{lat-delta},{lon+delta},{lat+delta}"
    url = "https://api3.geo.admin.ch/rest/services/all/MapServer/identify"

    params = {
        "geometryType": "esriGeometryEnvelope",
        "geometry": bbox,
        "layers": "all:ch.astra.veloland",
        "tolerance": 2,
        "returnGeometry": "true",
        "imageDisplay": "1920,1080,96",
        "mapExtent": bbox,
        "sr": "4326",
        "lang": "en",
        "f": "geojson"
    }

    response = requests.get(url, params=params)
    if response.status_code != 200:
        st.error(f"Erreur Swisstopo: {response.status_code}")
        return None

    geojson = response.json()
    if "features" not in geojson or not geojson["features"]:
        st.warning("Aucune piste cyclable trouvée dans cette zone.")
        return None

    all_paths = []
    for feature in geojson["features"]:
        coords = feature["geometry"]["coordinates"]
        if isinstance(coords[0][0], list):  # MultiLineString
            for segment in coords:
                path = [[lat, lon] for lon, lat in segment]
                all_paths.append(path)
        else:  # LineString
            path = [[lat, lon] for lon, lat in coords]
            all_paths.append(path)

    data = [{"path": path} for path in all_paths]

    layer = pdk.Layer(
        "PathLayer",
        data=data,
        get_path="path",
        get_color=[0, 200, 0],
        width_scale=10,
        width_min_pixels=2,
        pickable=False
    )

    view = pdk.ViewState(
        latitude=lat,
        longitude=lon,
        zoom=12,
        pitch=0
    )

    return {
        "layer": layer,
        "view": view
    }
